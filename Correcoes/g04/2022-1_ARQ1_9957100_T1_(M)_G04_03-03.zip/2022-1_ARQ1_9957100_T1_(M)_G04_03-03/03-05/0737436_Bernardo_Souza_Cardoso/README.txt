//Aluno: Bernardo Souza Cardoso
//Matrícula: 737436
//Curso: Ciência da Computação - Manhã 
//Guia04

Autoavaliação: Bem creio que entendi o conceito mais me pareceu muito confuso representar em verilog/logisim, talvez alguns exemplos a mais sobre seria de grande ajuda.
Obs: Caso tenha alguma duvida me chamar no canvas/sga pois fiz no caderno como sempre e transcrevo "Resumido" por assim dizer no txt, assim posso mandar fotos do caderno se preferir.