Na questão 2 letra c eu não consegui simplificar bem. 
Não sei se a minha resposta está certa.
Tem como fazer o $monitor parar?

OBS.: NÃO. ENQUANTO HOUVER MUDANÇAS DE VALOR, FUNCIONARÁ.
 
Não consegui colocar algumas das respostas 
em um mesmo arquivo porque eu precisava (de) 
limpar o que o $monitor estava mostrando e 
o único jeito que eu achei foi fazer um novo programa.

OBS.: TALVEZ POSSA SEPARAR EM VÁRIOS BLOCOS SEQUENCIAIS,
      MAS TERÁ QUE USAR UM CONTROLE PARA DESATIVAR CADA UM.
