README! 

1- Eu fiz os arquivos em meu PC com linux, 
   porém ele estragou a placa de rede, 
   portanto copiei tudo em meu pc com windows e 
   estou mandando em .txt e não em .v

OK. PODERIA DEIXAR EM .v MESMO, É TEXTO DA MESMA FORMA.
