Tive dificuldade em implementar as questoes 4 e 5 no verilog, vou tentar fazer posteriormente
