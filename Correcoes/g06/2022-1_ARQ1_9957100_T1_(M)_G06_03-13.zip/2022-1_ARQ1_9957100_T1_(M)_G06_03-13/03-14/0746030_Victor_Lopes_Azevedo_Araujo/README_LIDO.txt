Aluno: Victor Lopes Azevedo Araujo
N⁰ de Matricula: 746030

1.) Os circuitos do logisim estão todos separados 
    dentro do Guia06.circ

5.) a' + b + c

???

6.) 

OK.
