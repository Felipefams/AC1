Todas as questões estão resolvidas nos arquivos, 
exceto as extras. As questões que envolvem Verilog 
não consegui resolver, então o código em Verilog 
está em falta.

Peço desculpas por qualquer erro aparente, 
a guia estava muito pesada de exercícios e 
posso ter errado em alguns momentos, 
mesmo depois de conferido.

OK.

OS RECURSOS QUE PODEM AJUDAR NA CONFERÊNCIA
SÃO AS IMPLEMENTAÇÕES EM LINGUAGEM OU AS
COMPARAÇÕES DAS SAÍDAS DOS CIRCUITOS EQUIVALENTES.
