OS EXTRAS ESTAO DENTRO DO .CIRC
e uma pergunta theldo, to pensando em fazer um parser 
pra transformar expressao logica em codigo no verilog, 
ja com os prints de teste vc acha boa a ideia? 
ou nao compensa?

COMPENSA, SIM!
BOA IDEIA!
