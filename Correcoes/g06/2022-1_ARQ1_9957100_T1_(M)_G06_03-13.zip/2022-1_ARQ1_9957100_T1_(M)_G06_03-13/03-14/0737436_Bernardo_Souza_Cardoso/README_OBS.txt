// Aluno: Bernardo Souza Cardoso
// Matricula: 737436

Separei desta vez em pastas para as partes escritas em txt 
e logisim, sendo por exemplo cada uma questão nomeada com 
"01a", "01b"....."04a".
E as questões 05 e 06 não conseguir achar um exemplo 
correspondente em verilog para complementar á questão, 
então fiz oque pedia em Logisim e suas tabela/Mapa. 

O OBJETIVO DESSAS QUESTÕES ERA LEVANTAR A EXPRESSÃO
EQUIVALENTE PARA DEPOIS IMPLEMENTÁ-LA NO LOGISIM.

SIGA O EXEMPLO ABAIXO:

s = w1 | w2
w1 = w3 & w4
w2 = ~w7
w3 = ~w5
w4 = ~w6
w5 = w8 | w9
w6 = x & y
w7 = w10 | w11
w8 = ~y
w9 = ~x
w10 = y & z
w11 = ~x

DEPOIS É TERMINAR A SUBSTITUIÇÃO NA LINGUAGEM.
 