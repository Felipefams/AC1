Tem como fazer portão lógico com mais de uma entrada 
no verilog?

OBS.: É COM UM ARRANJO.
      ALGO ASSIM

      module SoP (output y, input [3:0] x );
