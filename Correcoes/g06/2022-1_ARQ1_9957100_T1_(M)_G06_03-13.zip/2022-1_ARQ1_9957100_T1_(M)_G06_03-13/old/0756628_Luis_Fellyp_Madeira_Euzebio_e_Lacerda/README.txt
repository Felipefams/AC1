Professor, durante a semana do carnaval viajei e cometi o erro de ir sem notebook, por isso nao pude fazer os 3 guias da referida semana (o 03 de domingo, o 04 do meio da semana e o 05 do outro domingo).

Li que o senhor avalia atividades enviadas muito tempo depois, mas como este tempo nao esta especificado resolvi enviar o guia 03 junto com os outros, de novo peco desculpas pelo meu erro.

Espero que realmente entenda, desde ja agradeco.

Att., Luis Fellyp Lacerda.