// Aluno: Bernardo Souza Cardoso
// Matricula: 737436

Separei desta vez em pastas para as partes escritas em txt e logisim, sendo por exemplo cada uma questão nomeada com "01a", "01b"....."04a".
E as questões 05 e 06 não conseguir achar um exemplo correspondente em verilog para complementar á questão, então fiz oque pedia em Logisim e suas tabela/Mapa. 
