Eu não consegui entender o que as questoes estavam pedindo 
em verilog

Também não entendi o codigo que foi dado como exemplo

OBS.: O CÓDIGO EM VERILOG PODERIA SERVIR COMO MODELO
      PARA AJUDAR NA IMPLEMENTAÇÃO E TESTE DE OUTROS.
      A PRIMEIRA FORMA (f5a) MOSTRA COMO IMPLEMENTAR
      POR PORTAS, E A SEGUNDA (f5b) POR EXPRESSÃO.
      AMBAS PODERIAM SER USADAS PARA TESTAR 
      AS DEFINIÇÕES E MONTAR AS TABELAS-VERDADES.
