Eu não consegui entender o que as questoes estavam pedindo em verilog
Também não entendi o codigo que foi dado como exemplo
