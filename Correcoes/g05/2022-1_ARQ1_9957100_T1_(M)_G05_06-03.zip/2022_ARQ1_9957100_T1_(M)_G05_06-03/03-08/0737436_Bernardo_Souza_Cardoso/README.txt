// Aluno: Bernardo Souza Cardoso
// Guia 05
// Matricula: 737436

Organizei os exercicios feitos no Logisim de acordo com numeração da pergunta, exemplo "Guia0501" -> remete ao primeiro exercicio e o Logisim "01 Circuito".
No entanto também deixei o plano de teste em comentário nos exercicios.