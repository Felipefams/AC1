/* 
ARQ1_AULA05
PONTIFICIA UNIVERSIDADE CATÓLICA DE MINAS GERAIS
INSTITUTO DE CIENCIAS EXATAS E INFORMATICA - ICEI
ARQUITETURA DE COMPUTADORES I 
ALUNO: JULIA VELOSO DIAS ID: 0746032
PROFESSOR: THELDO CRUZ FRANQUIERA
CURSO: CIENCIA DA COMPUTAÇÃO // TURNO: MANHÃ // PERIDO: SEGUNDO
*/ 

No arquivo há duas pastas, uma com codigos em .v e outra com a resolução no logisim, nessa ultima portanto existe um arquivo
em pdf com as resoluçoes das questões desenvolvidas no programa para visualização de pinos que podem vir a se tornar 0 quando 
abertos em outro computador e caso venha ocorrer, peço que também visualize o pdf para conferir. 
OBS.: Fiz a descoberta da alteração do 0 por meio de um colega que teve dificuldades em reabrir o programa e estava tudo alterado.

Todas as questoes estão testadas e funcionando perfeitamente em meu computador.