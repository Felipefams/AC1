Guia 05
Nome: JOAO VITOR LIMA DE MELO
Matricula: 748022

O arquivo Exemplo_0501.v contém o modelo seguido para o desenvolvimento dos programas em Verilog.

Extensões:
- Os arquivos .txt contém a previsão de testes da expressão. 
- Os arquivos .v são programas em Verilog que, usando apenas portas nativas nand e nor, descrevem um módulo equivalente à expressão.
- Os arquivos .circ simulam o módulo no Logisim e apresentam o layout do circuito e dos subcircuitos
