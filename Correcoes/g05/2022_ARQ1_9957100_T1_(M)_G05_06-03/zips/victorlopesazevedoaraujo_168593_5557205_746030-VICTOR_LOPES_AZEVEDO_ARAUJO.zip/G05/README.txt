Aluno: Victor Lopes Azevedo Araujo 
N⁰ de Matricula: 746030x

1.) As questões estão com os arquivos referentes ao numero das mesmas, exemplo:
Questão 01 com nome 0501, Questão 02 com nome 0502 ...

2.) Os circuitos do logisim estão todos separados dentro do Guia05.circ

